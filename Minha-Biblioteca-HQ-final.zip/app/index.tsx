import React, {useEffect, useMemo, useState} from 'react';
import {Alert, FlatList, Image, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Directory, File} from 'expo-file-system';
import {Comic, Library, supported, titleFromName} from '../src/library';
import {extractCover, openInCDisplayEx} from 'native-cover-extractor';

const KEY='library.v2';

export default function Home(){
  const [library,setLibrary]=useState<Library>({});
  const [query,setQuery]=useState('');
  const [selected,setSelected]=useState('Todos');
  const [loading,setLoading]=useState(false);
  const [coversLoading,setCoversLoading]=useState(false);

  useEffect(()=>{AsyncStorage.getItem(KEY).then(v=>v&&setLibrary(JSON.parse(v))).catch(()=>{});},[]);
  useEffect(()=>{AsyncStorage.setItem(KEY,JSON.stringify(library)).catch(()=>{});},[library]);

  const categories=['Todos',...Object.keys(library)];
  const books=useMemo(()=>{
    const all=Object.values(library).flat();
    return all.filter(b=>(selected==='Todos'||b.category===selected)&&b.name.toLowerCase().includes(query.toLowerCase()));
  },[library,selected,query]);

  async function chooseFolder(){
    try{
      setLoading(true);
      const dir=await Directory.pickDirectoryAsync();
      const found:Library={};
      await scan(dir, dir.name || 'Biblioteca', found);
      setLibrary(found);
      setSelected('Todos');
      setCoversLoading(true);
      await generateMissingCovers(found);
      setLibrary({...found});
    }catch(e){ Alert.alert('Não foi possível importar',String(e)); }
    finally{setLoading(false);setCoversLoading(false);}
  }

  async function scan(dir:Directory, category:string, out:Library){
    let entries: (File|Directory)[]=[];
    try{ entries=dir.list(); }catch{return;}
    for(const item of entries){
      if(item instanceof Directory){
        const nextCategory=category==='Biblioteca' ? item.name : category;
        await scan(item,nextCategory,out);
      }else if(supported.test(item.name)){
        const extension=item.name.split('.').pop()!.toLowerCase();
        const comic:Comic={id:item.uri,name:titleFromName(item.name),uri:item.uri,category,extension};
        (out[category]??=[]).push(comic);
      }
    }
  }

  async function generateMissingCovers(lib:Library){
    for(const category of Object.keys(lib)){
      for(const book of lib[category]){
        if(book.coverUri) continue;
        try{
          const safeId=encodeURIComponent(book.uri).replace(/%/g,'_').slice(-100);
          book.coverUri=await extractCover(book.uri,book.extension,`cover-${safeId}.jpg`);
        }catch(e){
          // Mantém a capa de fallback para arquivos problemáticos.
        }
        setLibrary({...lib});
      }
    }
  }

  async function openBook(book:Comic){
    try{
      await openInCDisplayEx(book.uri, book.extension);
    }catch(e){
      Alert.alert('Não foi possível abrir', 'Instale o CDisplayEx e tente novamente. Ele suporta CBR, CBZ e PDF.');
    }
  }

  function mime(ext:string){
    if(ext==='pdf') return 'application/pdf';
    if(ext==='cbr') return 'application/x-cbr';
    return 'application/x-cbz';
  }

  return <SafeAreaView style={s.root}>
    <View style={s.header}><Text style={s.title}>Minha Biblioteca HQ</Text><Text style={s.sub}>{books.length} quadrinhos{coversLoading?' • gerando capas...':''}</Text></View>
    <View style={s.search}><TextInput value={query} onChangeText={setQuery} placeholder="Pesquisar..." placeholderTextColor="#8b8f98" style={s.input}/></View>
    <FlatList horizontal data={categories} keyExtractor={x=>x} showsHorizontalScrollIndicator={false} contentContainerStyle={s.chips}
      renderItem={({item})=><Pressable onPress={()=>setSelected(item)} style={[s.chip,item===selected&&s.chipOn]}><Text style={[s.chipText,item===selected&&s.chipTextOn]}>{item}</Text></Pressable>}/>
    {books.length===0 ? <View style={s.empty}><Text style={s.emptyTitle}>{loading?'Lendo biblioteca...':'Sua biblioteca está vazia'}</Text><Text style={s.emptyText}>Escolha a pasta que contém suas categorias e quadrinhos.</Text><Pressable style={s.button} onPress={chooseFolder}><Text style={s.buttonText}>Escolher pasta</Text></Pressable></View> :
    <FlatList data={books} numColumns={2} keyExtractor={x=>x.id} contentContainerStyle={s.grid}
      renderItem={({item})=><Pressable style={s.card} onPress={()=>openBook(item)}>
        <View style={s.cover}>{item.coverUri ? <Image source={{uri:item.coverUri}} style={s.coverImage} resizeMode="cover"/> : <Text style={s.coverFallback}>{item.name.slice(0,1).toUpperCase()}</Text>}</View>
        <Text numberOfLines={2} style={s.bookName}>{item.name}</Text><Text style={s.format}>{item.extension.toUpperCase()}</Text>
      </Pressable>}/>} 
    <Pressable style={s.fab} onPress={chooseFolder}><Text style={s.fabText}>＋</Text></Pressable>
  </SafeAreaView>;
}

const s=StyleSheet.create({
 root:{flex:1,backgroundColor:'#0f1115'},header:{padding:20,paddingBottom:10},title:{fontSize:26,fontWeight:'800',color:'#fff'},sub:{color:'#9297a3',marginTop:4},
 search:{marginHorizontal:16,backgroundColor:'#191c22',borderRadius:14},input:{height:48,paddingHorizontal:16,color:'#fff',fontSize:16},
 chips:{paddingHorizontal:16,paddingVertical:14,gap:8},chip:{paddingHorizontal:14,paddingVertical:9,borderRadius:20,backgroundColor:'#191c22'},chipOn:{backgroundColor:'#e8edf5'},chipText:{color:'#b5bac5'},chipTextOn:{color:'#101217',fontWeight:'700'},
 grid:{padding:12,paddingBottom:100},card:{width:'50%',padding:8},cover:{height:245,borderRadius:8,backgroundColor:'#252a33',alignItems:'center',justifyContent:'center',overflow:'hidden'},coverImage:{width:'100%',height:'100%'},coverFallback:{fontSize:70,fontWeight:'900',color:'#606877'},bookName:{color:'#fff',fontWeight:'700',marginTop:8,fontSize:15},format:{color:'#747b88',fontSize:11,marginTop:3},
 empty:{flex:1,alignItems:'center',justifyContent:'center',padding:30},emptyTitle:{fontSize:22,fontWeight:'800',color:'#fff',textAlign:'center'},emptyText:{color:'#969ca8',textAlign:'center',marginTop:8,lineHeight:21},button:{marginTop:20,backgroundColor:'#e8edf5',paddingHorizontal:22,paddingVertical:13,borderRadius:12},buttonText:{color:'#111318',fontWeight:'800'},fab:{position:'absolute',right:20,bottom:25,width:58,height:58,borderRadius:29,backgroundColor:'#e8edf5',alignItems:'center',justifyContent:'center'},fabText:{fontSize:30,color:'#111318'}
});
