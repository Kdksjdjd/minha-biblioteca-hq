# Minha Biblioteca HQ

Biblioteca Android para PDF, CBR e CBZ. As pastas viram categorias, a capa é extraída da primeira página/imagem e os arquivos originais não são modificados.

## Build APK

Este projeto usa Expo SDK 57 + EAS Build. O perfil `preview` já está configurado para gerar APK instalável.

`eas build -p android --profile preview`

O build é feito na nuvem pelo EAS.
