import { NativeModules } from 'react-native';

const { CoverExtractor } = NativeModules;

export async function extractCover(uri, extension, outputName) {
  if (!CoverExtractor?.extractCover) throw new Error('Extrator nativo não disponível. Gere um APK/development build.');
  return CoverExtractor.extractCover(uri, extension, outputName || `cover-${Date.now()}.jpg`);
}

export async function openInCDisplayEx(uri, extension) {
  if (!CoverExtractor?.openInCDisplayEx) throw new Error('Módulo nativo não disponível.');
  return CoverExtractor.openInCDisplayEx(uri, extension);
}
