package com.edsonmarley.nativecover;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.github.junrar.Archive;
import com.github.junrar.rarfile.FileHeader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class CoverExtractorModule extends ReactContextBaseJavaModule {
  private final ReactApplicationContext context;
  public CoverExtractorModule(ReactApplicationContext context) { super(context); this.context = context; }
  @NonNull @Override public String getName() { return "CoverExtractor"; }

  @ReactMethod
  public void openInCDisplayEx(String uriString, String extension, Promise promise) {
    try {
      Uri uri = Uri.parse(uriString);
      String type = extension.equalsIgnoreCase("pdf") ? "application/pdf" : (extension.equalsIgnoreCase("cbr") ? "application/x-cbr" : "application/x-cbz");
      Intent intent = new Intent(Intent.ACTION_VIEW);
      intent.setDataAndType(uri, type);
      intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
      String[] packages = {"com.progdigy.cdisplay", "com.progdigy.cdisplay.free"};
      boolean opened = false;
      for (String pkg : packages) {
        try { intent.setPackage(pkg); context.startActivity(intent); opened = true; break; } catch (ActivityNotFoundException ignored) {}
      }
      if (!opened) {
        intent.setPackage(null);
        context.startActivity(intent);
      }
      promise.resolve(true);
    } catch (Exception e) { promise.reject("OPEN_ERROR", e.getMessage(), e); }
  }

  @ReactMethod
  public void extractCover(String uriString, String extension, String outputName, Promise promise) {
    try {
      String ext = extension.toLowerCase(Locale.US);
      File out = new File(context.getCacheDir(), "covers/" + outputName);
      File parent = out.getParentFile(); if (parent != null) parent.mkdirs();
      Bitmap bmp;
      if (ext.equals("pdf")) bmp = pdf(uriString);
      else if (ext.equals("cbz")) bmp = cbz(uriString);
      else if (ext.equals("cbr")) bmp = cbr(uriString);
      else throw new Exception("Formato não suportado");
      if (bmp == null) throw new Exception("Não foi possível encontrar a primeira imagem");
      FileOutputStream fos = new FileOutputStream(out);
      bmp.compress(Bitmap.CompressFormat.JPEG, 88, fos); fos.close(); bmp.recycle();
      promise.resolve(out.toURI().toString());
    } catch (Exception e) { promise.reject("COVER_ERROR", e.getMessage(), e); }
  }

  private InputStream input(String uri) throws Exception { return context.getContentResolver().openInputStream(Uri.parse(uri)); }

  private Bitmap pdf(String uri) throws Exception {
    ParcelFileDescriptor pfd;
    Uri u = Uri.parse(uri);
    if ("file".equals(u.getScheme())) pfd = ParcelFileDescriptor.open(new File(u.getPath()), ParcelFileDescriptor.MODE_READ_ONLY);
    else {
      File tmp = File.createTempFile("book", ".pdf", context.getCacheDir());
      copy(input(uri), new FileOutputStream(tmp));
      pfd = ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY);
    }
    PdfRenderer renderer = new PdfRenderer(pfd);
    PdfRenderer.Page page = renderer.openPage(0);
    int width = Math.max(600, page.getWidth() * 2), height = Math.max(800, page.getHeight() * 2);
    Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bmp); canvas.drawColor(Color.WHITE); page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
    page.close(); renderer.close(); pfd.close(); return bmp;
  }

  private Bitmap cbz(String uri) throws Exception {
    File tmp = materialize(uri, ".cbz");
    ZipFile zip = new ZipFile(tmp);
    ArrayList<? extends ZipEntry> entries = Collections.list(zip.entries());
    Collections.sort(entries, Comparator.comparing(ZipEntry::getName, String.CASE_INSENSITIVE_ORDER));
    for (ZipEntry e : entries) if (!e.isDirectory() && imageName(e.getName())) {
      Bitmap b = BitmapFactory.decodeStream(zip.getInputStream(e)); zip.close(); return b;
    }
    zip.close(); throw new Exception("Nenhuma imagem encontrada no CBZ");
  }

  private Bitmap cbr(String uri) throws Exception {
    File tmp = materialize(uri, ".cbr");
    Archive ar = new Archive(tmp);
    ArrayList<FileHeader> hs = new ArrayList<>();
    for (FileHeader h : ar.getFileHeaders()) if (!h.isDirectory() && imageName(h.getFileNameW())) hs.add(h);
    Collections.sort(hs, Comparator.comparing(FileHeader::getFileNameW, String.CASE_INSENSITIVE_ORDER));
    if (hs.isEmpty()) throw new Exception("Nenhuma imagem encontrada no CBR");
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    ar.extractFile(hs.get(0), baos); ar.close();
    return BitmapFactory.decodeByteArray(baos.toByteArray(), 0, baos.size());
  }

  private boolean imageName(String n) { String x=n.toLowerCase(Locale.US); return x.endsWith(".jpg")||x.endsWith(".jpeg")||x.endsWith(".png")||x.endsWith(".webp"); }
  private File materialize(String uri, String suffix) throws Exception { File f=File.createTempFile("book",suffix,context.getCacheDir()); copy(input(uri),new FileOutputStream(f)); return f; }
  private void copy(InputStream in, FileOutputStream out) throws Exception { byte[] buf=new byte[8192]; int n; try(InputStream i=in; FileOutputStream o=out){while((n=i.read(buf))!=-1)o.write(buf,0,n);} }
}
