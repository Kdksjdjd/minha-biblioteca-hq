export type Comic = {
  id: string;
  name: string;
  uri: string;
  category: string;
  extension: string;
  coverUri?: string;
};

export type Library = Record<string, Comic[]>;

export const supported = /\.(pdf|cbz|cbr)$/i;

export function titleFromName(name: string) {
  return name.replace(/\.(pdf|cbz|cbr)$/i, '').replace(/[_]+/g, ' ').trim();
}
